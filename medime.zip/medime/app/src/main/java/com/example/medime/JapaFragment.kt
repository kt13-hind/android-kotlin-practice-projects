package com.example.medime

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity.MODE_PRIVATE
import com.google.android.flexbox.FlexboxLayout


/**
 * A simple [Fragment] subclass.
 * Use the [JapaFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class JapaFragment : Fragment() {

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.fragment_japa, container, false)
        val time = view.findViewById<TextView>(R.id.time)
        val spiralView = view.findViewById<SpiralView>(R.id.imageButton)
        val sharedPreferences = requireContext().getSharedPreferences("data", MODE_PRIVATE)
        var times = 0
        var totalTimes = sharedPreferences.getInt("japaTimes", 0)
        spiralView.onBeadClickListener = {
            if (spiralView.filledCount == spiralView.totalCircles){
                time.text = String.format("%s times", ++times)
                Toast.makeText(view.context, "Yay you have completed 108 times japa!", Toast.LENGTH_SHORT).show()
                sharedPreferences.edit().putInt("japaTimes", totalTimes + times).apply()
                spiralView.filledCount = 0
            }
        }

        val resetBeads = view.findViewById<Button>(R.id.resetBeads)
        resetBeads.setOnClickListener {
            spiralView.onBeadsResetEvent()
            times = 0
            time.text = String.format("%s times", times)
        }

        return view
    }
}