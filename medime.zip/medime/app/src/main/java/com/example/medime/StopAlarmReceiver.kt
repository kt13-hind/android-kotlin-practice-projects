package com.example.medime

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class StopAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        AlarmPlayer.stopAlarm()

        // Optionally cancel the notification
        context.stopService(Intent(context, AlarmService::class.java))

    }
}