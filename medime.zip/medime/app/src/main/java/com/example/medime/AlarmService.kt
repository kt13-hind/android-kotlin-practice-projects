package com.example.medime

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import com.example.medime.AlarmPlayer.stopAlarm

class AlarmService : Service() {

    override fun onBind(p0: Intent?): IBinder? {
        return null
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {

        AlarmPlayer.startAlarm(this)
        showNotification(this)

        Handler(Looper.getMainLooper()).postDelayed({
            val stopIntent = Intent(this, StopAlarmReceiver::class.java)
            sendBroadcast(stopIntent)
        }, 10000)

        // If the system kills the service, recreate it with the same intent.
        return START_STICKY
    }

    private fun showNotification(context: Context) {
        val channelId = "medime_alarm_channel"
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId, "Medime Alarm Notifications",
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }
        val stopIntent = Intent(context, StopAlarmReceiver::class.java)
        val stopPendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val notification = NotificationCompat.Builder(context, channelId)
            .setContentTitle("Time's up!")
            .setContentText("Tap to stop the alarm.")
            .setSmallIcon(R.drawable.ic_launcher_foreground)
            .addAction(R.drawable.ic_launcher_foreground, "Stop", stopPendingIntent)
            .setAutoCancel(true)
            .build()

//        notificationManager.notify(1001, notification)
        startForeground(1001, notification)
    }


}
