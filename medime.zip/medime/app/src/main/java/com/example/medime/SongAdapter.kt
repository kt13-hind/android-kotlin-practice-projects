package com.example.medime

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class SongAdapter(
    private val songs: List<Song>,
    private val context: Context
) : RecyclerView.Adapter<SongAdapter.SongViewHolder>() {

    var selectedPosition = RecyclerView.NO_POSITION

    class SongViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val songName: TextView = itemView.findViewById(R.id.songName)
        val play: ImageButton = itemView.findViewById(R.id.playSong)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SongViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.ringtone_item, parent, false)
        return SongViewHolder(view)
    }

    override fun getItemCount(): Int = songs.size

    override fun onBindViewHolder(holder: SongViewHolder, position: Int) {
        val song = songs[position]
        holder.songName.text = song.name

        // Update UI based on selection
        holder.itemView.setBackgroundResource(
            if (selectedPosition == position) R.drawable.selected_background else android.R.color.transparent
        )

        holder.play.setImageResource(
            if (selectedPosition == position && AlarmPlayer.isPlaying) R.drawable.stop_solid
            else R.drawable.play_solid
        )

        // Play button click
        holder.itemView.setOnClickListener {
            val previouslySelected = selectedPosition

            if (selectedPosition == position && AlarmPlayer.isPlaying) {
                AlarmPlayer.stopAlarm()
            } else {
                AlarmPlayer.playSong(context, song.uri)
                selectedPosition = position
            }

            notifyItemChanged(previouslySelected)
            notifyItemChanged(position)
        }
    }

}
