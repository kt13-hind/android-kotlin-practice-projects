package com.example.medime

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import kotlin.math.cos
import kotlin.math.sin

class SpiralView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    // your drawing code here

    val totalCircles = 108
    var filledCount = 0


    private val basePaint = Paint().apply {
        style = Paint.Style.FILL
        color = Color.LTGRAY // Unfilled color
        isAntiAlias = true
    }

    private val filledPaint = Paint().apply {
        style = Paint.Style.FILL
        color = Color.CYAN
        isAntiAlias = true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val centerX = width / 2f
        val centerY = height / 2f
        val radiusStep = 4f
        val angleStep = (2 * Math.PI) / 12

        for (i in 0 until totalCircles) {
            val angle = i * angleStep
            val radius = i * radiusStep
            val x = (centerX + cos(angle) * radius).toFloat()
            val y = (centerY + sin(angle) * radius).toFloat()

            canvas.drawCircle(x, y, 12f, if (i < filledCount) filledPaint else basePaint)
        }
    }

    var onBeadClickListener: (() -> Unit)? = null

    fun onBeadsResetEvent() {
        try {
            filledCount = 0
            invalidate()
        } catch (error: Exception) {
            error.printStackTrace()
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            if (filledCount < totalCircles) {
                filledCount++
                onBeadClickListener?.invoke()
                invalidate()
            }
            return true
        }
        return super.onTouchEvent(event)
    }


}
