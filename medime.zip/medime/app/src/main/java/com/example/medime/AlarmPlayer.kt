package com.example.medime

import android.content.Context
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity.MODE_PRIVATE

object AlarmPlayer {
    var mediaPlayer: MediaPlayer? = null
    val isPlaying: Boolean
        get() = try {
            mediaPlayer?.isPlaying == true
        } catch (e: IllegalStateException) {
            false
        }

    fun stopAlarm() {
        if(isPlaying){
            mediaPlayer?.stop()
            mediaPlayer?.release()
        }
    }
    fun playSong(context: Context, uri : Uri) {
        if (isPlaying){
            mediaPlayer?.stop()
            mediaPlayer?.release()
        }
        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(context, uri)
                isLooping = true
                prepare()
                start()
            }
        } catch (e : Exception) {
            e.printStackTrace()
        }
    }

    fun startAlarm(context: Context) {
        val sharedPrefs = context.getSharedPreferences("data", MODE_PRIVATE)
//        val alarmUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
//            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val songUri = Uri.parse(sharedPrefs.getString("song", null))
        if (isPlaying){
            mediaPlayer?.stop()
            mediaPlayer?.release()
        }
        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(context, songUri)
                setAudioStreamType(AudioManager.STREAM_ALARM)
                isLooping = true
                prepare()
                start()
            }

        } catch (e : Exception) {
            e.printStackTrace()
        }

    }
}