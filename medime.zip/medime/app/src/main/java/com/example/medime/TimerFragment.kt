package com.example.medime

import android.app.AlarmManager
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity.MODE_PRIVATE
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.util.Calendar
import java.util.Locale

/**
 * A simple [Fragment] subclass.
 * Use the [TimerFragment.newInstance] factory method to
 * create an instance of context fragment.
 */
class TimerFragment : Fragment() {
    private lateinit var pickTime : TextView
    private var timerHours : Int = 0
    private var timerMins : Int = 0


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for context fragment
        val view = inflater.inflate(R.layout.fragment_timer, container, false)

        val sharedPreferences: SharedPreferences
        val context = requireContext()

        pickTime = view.findViewById(R.id.time)
        pickTime.setOnClickListener {
            timeTickerDialog(context)
        }

        val songs = listOf(
            Song("Calming", Uri.parse("android.resource://" + context.packageName + "/" + R.raw.calming_alarm)),
            Song("Daybreak Iphone", Uri.parse("android.resource://" + context.packageName + "/" + R.raw.daybreak_iphone_alarm)),
            Song("Early Riser", Uri.parse("android.resource://" + context.packageName + "/" + R.raw.early_riser)),
            Song("Life Calm", Uri.parse("android.resource://" + context.packageName + "/" + R.raw.life_calm_alarm))
        )
        sharedPreferences = context.getSharedPreferences("data", MODE_PRIVATE)

        val recyclerView = view.findViewById<RecyclerView>(R.id.recyclerView)
        recyclerView.layoutManager = LinearLayoutManager(context)

        val adapter = SongAdapter(songs, context)

        recyclerView.adapter = adapter

        // if there is no song selected
        if (!sharedPreferences.contains("song")){
            val editor = sharedPreferences.edit()
            editor.putString("song", songs[0].uri.toString())
            editor.putInt("songNumber", 0)
            editor.apply()
            adapter.selectedPosition = 0
            adapter.notifyItemChanged(0)
        } else {
            adapter.selectedPosition = sharedPreferences.getInt("songNumber", 0)
        }



        val buttons = listOf(
            view.findViewById<Button>(R.id.hour),
            view.findViewById<Button>(R.id.halfHour),
            view.findViewById<Button>(R.id.quaterHour),
            view.findViewById<Button>(R.id.tenMins),
            view.findViewById<Button>(R.id.fiveMins)
        )
        buttons[0].setOnClickListener { quickSetTimer(1, 0) }
        buttons[1].setOnClickListener { quickSetTimer(0, 30) }
        buttons[2].setOnClickListener { quickSetTimer(0, 15) }
        buttons[3].setOnClickListener { quickSetTimer(0, 10) }
        buttons[4].setOnClickListener { quickSetTimer(0, 5) }

        // button to set the timer
        view.findViewById<Button>(R.id.setTimer).setOnClickListener {
            if (timerHours != 0 || timerMins != 0) {
                val calendar = Calendar.getInstance()
                calendar.add(Calendar.HOUR_OF_DAY, timerHours)
                calendar.add(Calendar.MINUTE, timerMins) // Set 5 minutes from now
                scheduleAlarm(context, calendar.timeInMillis)
                Toast.makeText(context, "Alarm set for $timerHours : $timerMins", Toast.LENGTH_SHORT).show()
                AlarmPlayer.stopAlarm()
                quickSetTimer(0,0)
                val editor = sharedPreferences.edit()
                editor.putString("song", songs[adapter.selectedPosition].uri.toString())
                editor.putInt("songNumber", adapter.selectedPosition)
                editor.apply()

            } else {
                Toast.makeText(context, "Pick a time", Toast.LENGTH_SHORT).show()
            }

        }
        return view
    }

    private fun quickSetTimer(selectedHour : Int, selectedMinute : Int) {
        // Handle the selected time
        pickTime.text = String.format(Locale.US, "%02d:%02d", selectedHour, selectedMinute)
        timerHours = selectedHour
        timerMins = selectedMinute

    }


    fun timeTickerDialog(context: Context){
        val timePickerDialog = TimePickerDialog(
            context,
            { _, selectedHour, selectedMinute ->
                // Handle the selected time
                quickSetTimer(selectedHour, selectedMinute)
            },
            0,
            0,
            true // is24HourView
        )

        timePickerDialog.show()
    }

    fun scheduleAlarm(context: Context, triggerTimeMillis: Long) {
        val intent = Intent(context, AlarmReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerTimeMillis,
                    pendingIntent
                )
            }
        }
        else {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerTimeMillis,
                pendingIntent
            )
        }
    }


}